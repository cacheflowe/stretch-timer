Todo:
---
* Constants for timer & audio settings
* Init timer & audio settings with last stored preference
* clean up app and turn into a class
* replace completely unauthorize, stolen stretch images

